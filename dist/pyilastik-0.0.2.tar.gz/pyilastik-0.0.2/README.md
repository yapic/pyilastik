# pyilastik

[![Build Status](https://travis-ci.com/yapic/pyilastik.svg?branch=master)](https://travis-ci.com/yapic/pyilastik)

A python connector for [ilastik](http://ilastik.org)
project files (h5 format .ilp).

Developed by the CRFS (Core Research Facilities) of the DZNE (German Center
for Neurodegenerative Diseases).
